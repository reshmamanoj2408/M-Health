# Agile5552021Fall
This is a repository for CS 555 '21 Fall project
<br> <br/>
To use our application, you need to have Mongodb installed in your machine.
<br><br/>
please go to the "cs555-project" folder, run "yarn run dev" to start the frontend on "http://localhost:3000". 
<br/>
Also, go to the "backend" folder and run "npm start", that way you can get access to the database.
